export interface Address {
	address: string;
	city: string;
	state: string;
	country: string;
	zipcode: string;
	phonenumber: string;
}
